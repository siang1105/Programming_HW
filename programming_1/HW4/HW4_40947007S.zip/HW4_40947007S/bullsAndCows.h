#pragma once
void bullsAndCows (int *);