#pragma once
void hanoi(int32_t,int32_t,int32_t,int32_t);
void hanoi2 (int32_t);