#pragma once
int32_t taylor (int32_t);
