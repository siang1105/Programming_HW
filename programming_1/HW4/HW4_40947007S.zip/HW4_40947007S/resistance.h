#pragma once
double resistance (int32_t , int32_t);